from flask import Flask, render_template, flash, redirect, url_for, session, logging, request
import pymysql
from wtforms import Form, StringField, TextAreaField, PasswordField, validators
from passlib.hash import sha256_crypt
from functools import wraps
from data import Articles
app = Flask(__name__)
app.secret_key = 'Flash App'

# Config SQL
db = pymysql.connect (host="localhost", user="administrator",password="Lchxvier23!", database="projectflask")

Articles = Articles()

@app.route('/')
def index():
	return render_template('home.html')

@app.route('/about')
def about():
	return render_template('about.html')

@app.route('/articles')
def articles():
	return render_template('articles.html', 
		articles = Articles)

@app.route('/article/<string:id>/')
def article(id):
    return render_template('article.html', id=id,)

@app.route('/products')
def products():
	return render_template('products.html')

@app.route('/market')
def market():
	return render_template('market.html')

class RegisterForm(Form):
    name = StringField('Full Name', [validators.length(min=1, max=50)])
    username = StringField('Username', [validators.length(min=4, max=25)])
    email = StringField('Email', [validators.length(min=6, max=50)])
    password = PasswordField('Password', [validators.DataRequired(), validators.EqualTo('confirm', message = 'Passwords do not match')])
    confirm = PasswordField('Confirm Password')

@app.route('/register', methods = ['GET', "POST"])
def register():
    form = RegisterForm(request.form)
    if request.method == "POST" and form.validate():
        name = form.name.data
        email = form.email.data
        username = form.username.data
        password = sha256_crypt.hash(str(form.password.data))

        # Create cursor
        cursor = db.cursor()
        cursor.execute("INSERT INTO users(name, email, username, password) VALUES(%s, %s, %s, %s)",(name, email, username, password))

        # Commit to DB
        db.commit()

        # Close Connection
        db.close()

        flash('You are now registered and can login', 'success')
        return redirect(url_for('login'))

        return render_template('register.html')
    return render_template('register.html', form = form)

#user login
@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method== "POST":
        username = request.form['username']
        password_candidate = request.form['password']

        #Creat cursor
        cursor = db.cursor()

        # Get user by username
        result = cursor.execute("select * from users where username = %s", [username])
        if result > 0:
            data = cursor.fetchone()
            password = data[4]
            name = data[1]
            rgdate = data[5]
            email = data[2]


            # Compare passwords
            if sha256_crypt.verify(password_candidate, password):
                #app.logger.info('PASSWORD MATCHED')
                session['logged_in'] = True
                session['username'] = username
                session['name'] = name
                session['rgdate'] = rgdate
                session['email'] = email

                flash('You are now logged in', 'success')

                return redirect(url_for('dashboard'))  
            else:
                #app.logger.info('PASSWORD NOT MATCHED')
                flash('invaild login', 'danger')
                return render_template('login.html')
            cursor.close()
        else:
            #app.logger.info('NO USER')
            flash('Username not found', 'danger')
            return render_template('login.html')
    return render_template('login.html')

# check if user logged in
def is_logged_in(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('Unauthorized, Please login', 'Danger')
            return redirect(url_for('login'))
    return warp


@app.route('/logout')	
def logout():
    session.clear()
    flash('You are now logged out', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/drop', methods=["GET", "POST"])
def drop():
    cursor = db.cursor()
    result = cursor.execute("delete  from users where username = %s", {session['username']})
    db.commit()
    session.clear()
    flash('Your account was deleted', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
	app.run(debug=True)